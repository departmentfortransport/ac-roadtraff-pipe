library(testthat)
library(xltabr)
library(magrittr)

test_check("xltabr")
